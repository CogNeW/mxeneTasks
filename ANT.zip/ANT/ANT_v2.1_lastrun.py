﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2020.2.5),
    on June 11, 2021, at 10:14
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, parallel
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2020.2.5'
expName = 'ANT_Test_2.0'  # from the Builder filename that created this script
expInfo = {'participant': '', 'session': '001'}
dlg = gui.DlgFromDict(dictionary=expInfo, sort_keys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\CogNeW\\Desktop\\ANT\\ANT_v2.1_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.DEBUG)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1920, 1080], fullscr=True, screen=0, 
    winType='pyglet', allowGUI=False, allowStencil=False,
    monitor='testMonitor', color='white', colorSpace='dkl',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "Instructions_1"
Instructions_1Clock = core.Clock()
Instructions = visual.TextStim(win=win, name='Instructions',
    text="This is an experiment investigating attention. You will be shown an arrow on the screen pointing either to the left or to the right.\n\n(for example > or < )\n\nOn some trials, the arrow will be flanked by two arrows to the left and two arrows to the right. \n\n(for example >>>>> or >><>>)\n\nYour task is to respond to the direction of the CENTRAL arrow. \n\nPress 'Spacebar' to continue.",
    font='Arial',
    pos=(0, 0), height=.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_4 = keyboard.Keyboard()

# Initialize components for Routine "Instructions_2"
Instructions_2Clock = core.Clock()
Instructions2 = visual.TextStim(win=win, name='Instructions2',
    text="You should press the left arrow key if the central arrow points to the left or the right arrow key if the central arrow points to the right. \n\nPlease make your response as quickly and accurately as possible. Your reaction time and accuracy will be recorded.\n\nPress 'Spacebar' to continue.\n",
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_2 = keyboard.Keyboard()

# Initialize components for Routine "Instructions_3"
Instructions_3Clock = core.Clock()
Instructions3 = visual.TextStim(win=win, name='Instructions3',
    text='There will be a cross ("+") in the center of the screen and the arrows will appear either above or below the cross. \n\nYou should try to fixate on the cross throughout the experiment.\n\nPress \'Spacebar\' to continue.',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_3 = keyboard.Keyboard()

# Initialize components for Routine "Instructions_4"
Instructions_4Clock = core.Clock()
text_3 = visual.TextStim(win=win, name='text_3',
    text="On some trials there will be * cues indicating when or where the arrow will occur. If the cue is at the center or both above and below fixation it indicates that the arrow will appear shortly. \n\nIf the cue is only above or below fixation it indicates both that the trial will occur shortly and where it will occur.\n\nTry to maintain fixation at all times.  However, you may attend when and where indicated by the cues.\n\nPress 'Spacebar' to continue.",
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_8 = keyboard.Keyboard()

# Initialize components for Routine "Instructions_5"
Instructions_5Clock = core.Clock()
text_2 = visual.TextStim(win=win, name='text_2',
    text='The experiment contains four blocks. The first block is for practice and takes about two minutes. The other three blocks are experimental blocks and each takes about five minutes.  \n\nAfter each block there will be a message "take a break" and you may take a short rest.  After it, you can press the space bar to begin the next block.  The whole experiment takes about twenty minutes.\n\nIf you have any questions, please ask the experimenter. \n\nPress \'Spacebar\' to start the practice trials. ',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_7 = keyboard.Keyboard()

# Initialize components for Routine "Prac_FixCue"
Prac_FixCueClock = core.Clock()
Prac_Fixation = visual.ImageStim(
    win=win,
    name='Prac_Fixation', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(1,1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-1.0)
Prac_Cue1 = visual.ImageStim(
    win=win,
    name='Prac_Cue1', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(1,1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-2.0)
Prac_Cue2 = visual.ImageStim(
    win=win,
    name='Prac_Cue2', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(1,1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-3.0)

# Initialize components for Routine "Prac_Trial"
Prac_TrialClock = core.Clock()
Prac_Fixation2 = visual.ImageStim(
    win=win,
    name='Prac_Fixation2', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(1,1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=0.0)
PracTarget = visual.ImageStim(
    win=win,
    name='PracTarget', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(.55,.55),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-1.0)
PracFlanker1 = visual.ImageStim(
    win=win,
    name='PracFlanker1', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(.55,.55),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-2.0)
PracFlanker2 = visual.ImageStim(
    win=win,
    name='PracFlanker2', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(.55,.55),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-3.0)
PracFlanker3 = visual.ImageStim(
    win=win,
    name='PracFlanker3', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(.55,.55),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-4.0)
PracFlanker4 = visual.ImageStim(
    win=win,
    name='PracFlanker4', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(.55,.55),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-5.0)
PracKey = keyboard.Keyboard()

# Initialize components for Routine "Feedback"
FeedbackClock = core.Clock()
#msg variable just needs some value at start
msg=''
Feedback_screen = visual.TextStim(win=win, name='Feedback_screen',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Initialize components for Routine "EndPrac"
EndPracClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text="Practice is over. Remember to respond ONLY to the middle arrow. Also, please make your response as quickly and accurately as possible. Your reaction time and accuracy will be recorded.\n\nHit 'Spacebar' to start the experiment.\n",
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_5 = keyboard.Keyboard()

# Initialize components for Routine "startProbe"
startProbeClock = core.Clock()
p_port = parallel.ParallelPort(address='0xCFF8')
image = visual.ImageStim(
    win=win,
    name='image', units='degFlatPos', 
    image='images/Fixation.png', mask=None,
    ori=0, pos=(0, 0), size=(1, 1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=False, depth=-1.0)

# Initialize components for Routine "Exp_FixCue"
Exp_FixCueClock = core.Clock()
trialStartPort = parallel.ParallelPort(address='0xCFF8')
Exp_Fixation = visual.ImageStim(
    win=win,
    name='Exp_Fixation', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(1,1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-2.0)
Exp_Cue1 = visual.ImageStim(
    win=win,
    name='Exp_Cue1', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(1,1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-3.0)
Exp_Cue2 = visual.ImageStim(
    win=win,
    name='Exp_Cue2', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(1,1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-4.0)
cuePort = parallel.ParallelPort(address='0xCFF8')

# Initialize components for Routine "Exp_Trial"
Exp_TrialClock = core.Clock()
Exp_Fixation2 = visual.ImageStim(
    win=win,
    name='Exp_Fixation2', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(1,1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=0.0)
Exp_Target = visual.ImageStim(
    win=win,
    name='Exp_Target', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(.55,.55),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-1.0)
Exp_Flanker1 = visual.ImageStim(
    win=win,
    name='Exp_Flanker1', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(.55,.55),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-2.0)
Exp_Flanker2 = visual.ImageStim(
    win=win,
    name='Exp_Flanker2', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(.55,.55),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-3.0)
Exp_Flanker3 = visual.ImageStim(
    win=win,
    name='Exp_Flanker3', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(.55,.55),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-4.0)
Exp_Flanker4 = visual.ImageStim(
    win=win,
    name='Exp_Flanker4', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(.55,.55),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-5.0)
ExpResp = keyboard.Keyboard()
targetPort = parallel.ParallelPort(address='0xCFF8')

# Initialize components for Routine "ping"
pingClock = core.Clock()
responsePort = parallel.ParallelPort(address='0xCFF8')
fixationEnd = visual.ImageStim(
    win=win,
    name='fixationEnd', units='degFlat', 
    image='sin', mask=None,
    ori=0, pos=[0,0], size=(1, 1),
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=512, interpolate=False, depth=-1.0)

# Initialize components for Routine "Break"
BreakClock = core.Clock()
Break_Slide = visual.TextStim(win=win, name='Break_Slide',
    text="You are on a break between blocks. Please wait at least 5 seconds and then press 'Spacebar' when you are ready to continue.",
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp = keyboard.Keyboard()

# Initialize components for Routine "EndStudy"
EndStudyClock = core.Clock()
EndofStudy = visual.TextStim(win=win, name='EndofStudy',
    text='The study is over. Thank you for participating!',
    font='Arial',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_6 = keyboard.Keyboard()

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "Instructions_1"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_4.keys = []
key_resp_4.rt = []
_key_resp_4_allKeys = []
# keep track of which components have finished
Instructions_1Components = [Instructions, key_resp_4]
for thisComponent in Instructions_1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Instructions_1Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Instructions_1"-------
while continueRoutine:
    # get current time
    t = Instructions_1Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Instructions_1Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *Instructions* updates
    if Instructions.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        Instructions.frameNStart = frameN  # exact frame index
        Instructions.tStart = t  # local t and not account for scr refresh
        Instructions.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(Instructions, 'tStartRefresh')  # time at next scr refresh
        Instructions.setAutoDraw(True)
    
    # *key_resp_4* updates
    waitOnFlip = False
    if key_resp_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_4.frameNStart = frameN  # exact frame index
        key_resp_4.tStart = t  # local t and not account for scr refresh
        key_resp_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_4, 'tStartRefresh')  # time at next scr refresh
        key_resp_4.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_4.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_4.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_4.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_4_allKeys.extend(theseKeys)
        if len(_key_resp_4_allKeys):
            key_resp_4.keys = _key_resp_4_allKeys[-1].name  # just the last key pressed
            key_resp_4.rt = _key_resp_4_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Instructions_1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instructions_1"-------
for thisComponent in Instructions_1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('Instructions.started', Instructions.tStartRefresh)
thisExp.addData('Instructions.stopped', Instructions.tStopRefresh)
# check responses
if key_resp_4.keys in ['', [], None]:  # No response was made
    key_resp_4.keys = None
thisExp.addData('key_resp_4.keys',key_resp_4.keys)
if key_resp_4.keys != None:  # we had a response
    thisExp.addData('key_resp_4.rt', key_resp_4.rt)
thisExp.addData('key_resp_4.started', key_resp_4.tStartRefresh)
thisExp.addData('key_resp_4.stopped', key_resp_4.tStopRefresh)
thisExp.nextEntry()
# the Routine "Instructions_1" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Instructions_2"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_2.keys = []
key_resp_2.rt = []
_key_resp_2_allKeys = []
# keep track of which components have finished
Instructions_2Components = [Instructions2, key_resp_2]
for thisComponent in Instructions_2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Instructions_2Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Instructions_2"-------
while continueRoutine:
    # get current time
    t = Instructions_2Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Instructions_2Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *Instructions2* updates
    if Instructions2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        Instructions2.frameNStart = frameN  # exact frame index
        Instructions2.tStart = t  # local t and not account for scr refresh
        Instructions2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(Instructions2, 'tStartRefresh')  # time at next scr refresh
        Instructions2.setAutoDraw(True)
    
    # *key_resp_2* updates
    waitOnFlip = False
    if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.tStart = t  # local t and not account for scr refresh
        key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_2.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_2.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_2_allKeys.extend(theseKeys)
        if len(_key_resp_2_allKeys):
            key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
            key_resp_2.rt = _key_resp_2_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Instructions_2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instructions_2"-------
for thisComponent in Instructions_2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('Instructions2.started', Instructions2.tStartRefresh)
thisExp.addData('Instructions2.stopped', Instructions2.tStopRefresh)
# check responses
if key_resp_2.keys in ['', [], None]:  # No response was made
    key_resp_2.keys = None
thisExp.addData('key_resp_2.keys',key_resp_2.keys)
if key_resp_2.keys != None:  # we had a response
    thisExp.addData('key_resp_2.rt', key_resp_2.rt)
thisExp.addData('key_resp_2.started', key_resp_2.tStartRefresh)
thisExp.addData('key_resp_2.stopped', key_resp_2.tStopRefresh)
thisExp.nextEntry()
# the Routine "Instructions_2" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Instructions_3"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_3.keys = []
key_resp_3.rt = []
_key_resp_3_allKeys = []
# keep track of which components have finished
Instructions_3Components = [Instructions3, key_resp_3]
for thisComponent in Instructions_3Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Instructions_3Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Instructions_3"-------
while continueRoutine:
    # get current time
    t = Instructions_3Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Instructions_3Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *Instructions3* updates
    if Instructions3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        Instructions3.frameNStart = frameN  # exact frame index
        Instructions3.tStart = t  # local t and not account for scr refresh
        Instructions3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(Instructions3, 'tStartRefresh')  # time at next scr refresh
        Instructions3.setAutoDraw(True)
    
    # *key_resp_3* updates
    waitOnFlip = False
    if key_resp_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_3.frameNStart = frameN  # exact frame index
        key_resp_3.tStart = t  # local t and not account for scr refresh
        key_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
        key_resp_3.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_3.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_3.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_3_allKeys.extend(theseKeys)
        if len(_key_resp_3_allKeys):
            key_resp_3.keys = _key_resp_3_allKeys[-1].name  # just the last key pressed
            key_resp_3.rt = _key_resp_3_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Instructions_3Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instructions_3"-------
for thisComponent in Instructions_3Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('Instructions3.started', Instructions3.tStartRefresh)
thisExp.addData('Instructions3.stopped', Instructions3.tStopRefresh)
# check responses
if key_resp_3.keys in ['', [], None]:  # No response was made
    key_resp_3.keys = None
thisExp.addData('key_resp_3.keys',key_resp_3.keys)
if key_resp_3.keys != None:  # we had a response
    thisExp.addData('key_resp_3.rt', key_resp_3.rt)
thisExp.addData('key_resp_3.started', key_resp_3.tStartRefresh)
thisExp.addData('key_resp_3.stopped', key_resp_3.tStopRefresh)
thisExp.nextEntry()
# the Routine "Instructions_3" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Instructions_4"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_8.keys = []
key_resp_8.rt = []
_key_resp_8_allKeys = []
# keep track of which components have finished
Instructions_4Components = [text_3, key_resp_8]
for thisComponent in Instructions_4Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Instructions_4Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Instructions_4"-------
while continueRoutine:
    # get current time
    t = Instructions_4Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Instructions_4Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_3* updates
    if text_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_3.frameNStart = frameN  # exact frame index
        text_3.tStart = t  # local t and not account for scr refresh
        text_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_3, 'tStartRefresh')  # time at next scr refresh
        text_3.setAutoDraw(True)
    
    # *key_resp_8* updates
    waitOnFlip = False
    if key_resp_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_8.frameNStart = frameN  # exact frame index
        key_resp_8.tStart = t  # local t and not account for scr refresh
        key_resp_8.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_8, 'tStartRefresh')  # time at next scr refresh
        key_resp_8.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_8.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_8.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_8.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_8.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_8_allKeys.extend(theseKeys)
        if len(_key_resp_8_allKeys):
            key_resp_8.keys = _key_resp_8_allKeys[-1].name  # just the last key pressed
            key_resp_8.rt = _key_resp_8_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Instructions_4Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instructions_4"-------
for thisComponent in Instructions_4Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text_3.started', text_3.tStartRefresh)
thisExp.addData('text_3.stopped', text_3.tStopRefresh)
# check responses
if key_resp_8.keys in ['', [], None]:  # No response was made
    key_resp_8.keys = None
thisExp.addData('key_resp_8.keys',key_resp_8.keys)
if key_resp_8.keys != None:  # we had a response
    thisExp.addData('key_resp_8.rt', key_resp_8.rt)
thisExp.addData('key_resp_8.started', key_resp_8.tStartRefresh)
thisExp.addData('key_resp_8.stopped', key_resp_8.tStopRefresh)
thisExp.nextEntry()
# the Routine "Instructions_4" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "Instructions_5"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_7.keys = []
key_resp_7.rt = []
_key_resp_7_allKeys = []
# keep track of which components have finished
Instructions_5Components = [text_2, key_resp_7]
for thisComponent in Instructions_5Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
Instructions_5Clock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "Instructions_5"-------
while continueRoutine:
    # get current time
    t = Instructions_5Clock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=Instructions_5Clock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_2* updates
    if text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_2.frameNStart = frameN  # exact frame index
        text_2.tStart = t  # local t and not account for scr refresh
        text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
        text_2.setAutoDraw(True)
    
    # *key_resp_7* updates
    waitOnFlip = False
    if key_resp_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_7.frameNStart = frameN  # exact frame index
        key_resp_7.tStart = t  # local t and not account for scr refresh
        key_resp_7.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_7, 'tStartRefresh')  # time at next scr refresh
        key_resp_7.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_7.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_7.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_7.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_7.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_7_allKeys.extend(theseKeys)
        if len(_key_resp_7_allKeys):
            key_resp_7.keys = _key_resp_7_allKeys[-1].name  # just the last key pressed
            key_resp_7.rt = _key_resp_7_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in Instructions_5Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "Instructions_5"-------
for thisComponent in Instructions_5Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text_2.started', text_2.tStartRefresh)
thisExp.addData('text_2.stopped', text_2.tStopRefresh)
# check responses
if key_resp_7.keys in ['', [], None]:  # No response was made
    key_resp_7.keys = None
thisExp.addData('key_resp_7.keys',key_resp_7.keys)
if key_resp_7.keys != None:  # we had a response
    thisExp.addData('key_resp_7.rt', key_resp_7.rt)
thisExp.addData('key_resp_7.started', key_resp_7.tStartRefresh)
thisExp.addData('key_resp_7.stopped', key_resp_7.tStopRefresh)
thisExp.nextEntry()
# the Routine "Instructions_5" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Prac = data.TrialHandler(nReps=1, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('ANT_TrialSheet_Prac.xlsx'),
    seed=None, name='Prac')
thisExp.addLoop(Prac)  # add the loop to the experiment
thisPrac = Prac.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisPrac.rgb)
if thisPrac != None:
    for paramName in thisPrac:
        exec('{} = thisPrac[paramName]'.format(paramName))

for thisPrac in Prac:
    currentLoop = Prac
    # abbreviate parameter names if possible (e.g. rgb = thisPrac.rgb)
    if thisPrac != None:
        for paramName in thisPrac:
            exec('{} = thisPrac[paramName]'.format(paramName))
    
    # ------Prepare to start Routine "Prac_FixCue"-------
    continueRoutine = True
    # update component parameters for each repeat
    jitter = np.random.choice(np.arange(.4, 1.6, .1))
    jitter2 = jitter + .5
    jitter3 = 4-jitter
    
    Prac_Fixation.setPos((PFixation_LocationX,PFixation_LocationY))
    Prac_Fixation.setImage(PFixation)
    Prac_Cue1.setPos((PCue1_LocationX,PCue1_LocationY))
    Prac_Cue1.setImage(PCue1)
    Prac_Cue2.setPos((PCue2_LocationX,PCue2_LocationY))
    Prac_Cue2.setImage(PCue2)
    # keep track of which components have finished
    Prac_FixCueComponents = [Prac_Fixation, Prac_Cue1, Prac_Cue2]
    for thisComponent in Prac_FixCueComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Prac_FixCueClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Prac_FixCue"-------
    while continueRoutine:
        # get current time
        t = Prac_FixCueClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Prac_FixCueClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Prac_Fixation* updates
        if Prac_Fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Prac_Fixation.frameNStart = frameN  # exact frame index
            Prac_Fixation.tStart = t  # local t and not account for scr refresh
            Prac_Fixation.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Prac_Fixation, 'tStartRefresh')  # time at next scr refresh
            Prac_Fixation.setAutoDraw(True)
        if Prac_Fixation.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Prac_Fixation.tStartRefresh + jitter2-frameTolerance:
                # keep track of stop time/frame for later
                Prac_Fixation.tStop = t  # not accounting for scr refresh
                Prac_Fixation.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Prac_Fixation, 'tStopRefresh')  # time at next scr refresh
                Prac_Fixation.setAutoDraw(False)
        
        # *Prac_Cue1* updates
        if Prac_Cue1.status == NOT_STARTED and tThisFlip >= jitter-frameTolerance:
            # keep track of start time/frame for later
            Prac_Cue1.frameNStart = frameN  # exact frame index
            Prac_Cue1.tStart = t  # local t and not account for scr refresh
            Prac_Cue1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Prac_Cue1, 'tStartRefresh')  # time at next scr refresh
            Prac_Cue1.setAutoDraw(True)
        if Prac_Cue1.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Prac_Cue1.tStartRefresh + .1-frameTolerance:
                # keep track of stop time/frame for later
                Prac_Cue1.tStop = t  # not accounting for scr refresh
                Prac_Cue1.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Prac_Cue1, 'tStopRefresh')  # time at next scr refresh
                Prac_Cue1.setAutoDraw(False)
        
        # *Prac_Cue2* updates
        if Prac_Cue2.status == NOT_STARTED and tThisFlip >= jitter-frameTolerance:
            # keep track of start time/frame for later
            Prac_Cue2.frameNStart = frameN  # exact frame index
            Prac_Cue2.tStart = t  # local t and not account for scr refresh
            Prac_Cue2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Prac_Cue2, 'tStartRefresh')  # time at next scr refresh
            Prac_Cue2.setAutoDraw(True)
        if Prac_Cue2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Prac_Cue2.tStartRefresh + .1-frameTolerance:
                # keep track of stop time/frame for later
                Prac_Cue2.tStop = t  # not accounting for scr refresh
                Prac_Cue2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Prac_Cue2, 'tStopRefresh')  # time at next scr refresh
                Prac_Cue2.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Prac_FixCueComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Prac_FixCue"-------
    for thisComponent in Prac_FixCueComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "Prac_FixCue" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "Prac_Trial"-------
    continueRoutine = True
    # update component parameters for each repeat
    Prac_Fixation2.setPos((PFixation_LocationX,PFixation_LocationY))
    Prac_Fixation2.setImage(PFixation)
    PracTarget.setPos((PTarget_Arrow_LocationX,PTarget_Arrow_LocationY))
    PracTarget.setImage(PTarget_Arrow)
    PracFlanker1.setPos((PFlanker1_LocationX,PFlanker1_LocationY))
    PracFlanker1.setImage(PFlanker1)
    PracFlanker2.setPos((PFlanker2_LocationX,PFlanker2_LocationY))
    PracFlanker2.setImage(PFlanker2)
    PracFlanker3.setPos((PFlanker3_LocationX,PFlanker3_LocationY))
    PracFlanker3.setImage(PFlanker3)
    PracFlanker4.setPos((PFlanker4_LocationX,PFlanker4_LocationY))
    PracFlanker4.setImage(PFlanker4)
    PracKey.keys = []
    PracKey.rt = []
    _PracKey_allKeys = []
    # keep track of which components have finished
    Prac_TrialComponents = [Prac_Fixation2, PracTarget, PracFlanker1, PracFlanker2, PracFlanker3, PracFlanker4, PracKey]
    for thisComponent in Prac_TrialComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    Prac_TrialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Prac_Trial"-------
    while continueRoutine:
        # get current time
        t = Prac_TrialClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=Prac_TrialClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Prac_Fixation2* updates
        if Prac_Fixation2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Prac_Fixation2.frameNStart = frameN  # exact frame index
            Prac_Fixation2.tStart = t  # local t and not account for scr refresh
            Prac_Fixation2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Prac_Fixation2, 'tStartRefresh')  # time at next scr refresh
            Prac_Fixation2.setAutoDraw(True)
        if Prac_Fixation2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Prac_Fixation2.tStartRefresh + jitter3-frameTolerance:
                # keep track of stop time/frame for later
                Prac_Fixation2.tStop = t  # not accounting for scr refresh
                Prac_Fixation2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Prac_Fixation2, 'tStopRefresh')  # time at next scr refresh
                Prac_Fixation2.setAutoDraw(False)
        
        # *PracTarget* updates
        if PracTarget.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
            # keep track of start time/frame for later
            PracTarget.frameNStart = frameN  # exact frame index
            PracTarget.tStart = t  # local t and not account for scr refresh
            PracTarget.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PracTarget, 'tStartRefresh')  # time at next scr refresh
            PracTarget.setAutoDraw(True)
        if PracTarget.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > PracTarget.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                PracTarget.tStop = t  # not accounting for scr refresh
                PracTarget.frameNStop = frameN  # exact frame index
                win.timeOnFlip(PracTarget, 'tStopRefresh')  # time at next scr refresh
                PracTarget.setAutoDraw(False)
        
        # *PracFlanker1* updates
        if PracFlanker1.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
            # keep track of start time/frame for later
            PracFlanker1.frameNStart = frameN  # exact frame index
            PracFlanker1.tStart = t  # local t and not account for scr refresh
            PracFlanker1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PracFlanker1, 'tStartRefresh')  # time at next scr refresh
            PracFlanker1.setAutoDraw(True)
        if PracFlanker1.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > PracFlanker1.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                PracFlanker1.tStop = t  # not accounting for scr refresh
                PracFlanker1.frameNStop = frameN  # exact frame index
                win.timeOnFlip(PracFlanker1, 'tStopRefresh')  # time at next scr refresh
                PracFlanker1.setAutoDraw(False)
        
        # *PracFlanker2* updates
        if PracFlanker2.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
            # keep track of start time/frame for later
            PracFlanker2.frameNStart = frameN  # exact frame index
            PracFlanker2.tStart = t  # local t and not account for scr refresh
            PracFlanker2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PracFlanker2, 'tStartRefresh')  # time at next scr refresh
            PracFlanker2.setAutoDraw(True)
        if PracFlanker2.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > PracFlanker2.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                PracFlanker2.tStop = t  # not accounting for scr refresh
                PracFlanker2.frameNStop = frameN  # exact frame index
                win.timeOnFlip(PracFlanker2, 'tStopRefresh')  # time at next scr refresh
                PracFlanker2.setAutoDraw(False)
        
        # *PracFlanker3* updates
        if PracFlanker3.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
            # keep track of start time/frame for later
            PracFlanker3.frameNStart = frameN  # exact frame index
            PracFlanker3.tStart = t  # local t and not account for scr refresh
            PracFlanker3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PracFlanker3, 'tStartRefresh')  # time at next scr refresh
            PracFlanker3.setAutoDraw(True)
        if PracFlanker3.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > PracFlanker3.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                PracFlanker3.tStop = t  # not accounting for scr refresh
                PracFlanker3.frameNStop = frameN  # exact frame index
                win.timeOnFlip(PracFlanker3, 'tStopRefresh')  # time at next scr refresh
                PracFlanker3.setAutoDraw(False)
        
        # *PracFlanker4* updates
        if PracFlanker4.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
            # keep track of start time/frame for later
            PracFlanker4.frameNStart = frameN  # exact frame index
            PracFlanker4.tStart = t  # local t and not account for scr refresh
            PracFlanker4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PracFlanker4, 'tStartRefresh')  # time at next scr refresh
            PracFlanker4.setAutoDraw(True)
        if PracFlanker4.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > PracFlanker4.tStartRefresh + 1.7-frameTolerance:
                # keep track of stop time/frame for later
                PracFlanker4.tStop = t  # not accounting for scr refresh
                PracFlanker4.frameNStop = frameN  # exact frame index
                win.timeOnFlip(PracFlanker4, 'tStopRefresh')  # time at next scr refresh
                PracFlanker4.setAutoDraw(False)
        
        # *PracKey* updates
        waitOnFlip = False
        if PracKey.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
            # keep track of start time/frame for later
            PracKey.frameNStart = frameN  # exact frame index
            PracKey.tStart = t  # local t and not account for scr refresh
            PracKey.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(PracKey, 'tStartRefresh')  # time at next scr refresh
            PracKey.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(PracKey.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(PracKey.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if PracKey.status == STARTED and not waitOnFlip:
            theseKeys = PracKey.getKeys(keyList=['left', 'right'], waitRelease=False)
            _PracKey_allKeys.extend(theseKeys)
            if len(_PracKey_allKeys):
                PracKey.keys = _PracKey_allKeys[0].name  # just the first key pressed
                PracKey.rt = _PracKey_allKeys[0].rt
                # was this correct?
                if (PracKey.keys == str(Correct)) or (PracKey.keys == Correct):
                    PracKey.corr = 1
                else:
                    PracKey.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in Prac_TrialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Prac_Trial"-------
    for thisComponent in Prac_TrialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if PracKey.keys in ['', [], None]:  # No response was made
        PracKey.keys = None
        # was no response the correct answer?!
        if str(Correct).lower() == 'none':
           PracKey.corr = 1;  # correct non-response
        else:
           PracKey.corr = 0;  # failed to respond (incorrectly)
    # store data for Prac (TrialHandler)
    Prac.addData('PracKey.keys',PracKey.keys)
    Prac.addData('PracKey.corr', PracKey.corr)
    if PracKey.keys != None:  # we had a response
        Prac.addData('PracKey.rt', PracKey.rt)
    # the Routine "Prac_Trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "Feedback"-------
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    if PracKey.corr:#stored on last run routine
      msg="Correct! RT=%.3f" %(PracKey.rt)
    else:
      msg="Oops! That was wrong"
    Feedback_screen.setText(msg)
    # keep track of which components have finished
    FeedbackComponents = [Feedback_screen]
    for thisComponent in FeedbackComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    FeedbackClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Feedback"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = FeedbackClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=FeedbackClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Feedback_screen* updates
        if Feedback_screen.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Feedback_screen.frameNStart = frameN  # exact frame index
            Feedback_screen.tStart = t  # local t and not account for scr refresh
            Feedback_screen.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Feedback_screen, 'tStartRefresh')  # time at next scr refresh
            Feedback_screen.setAutoDraw(True)
        if Feedback_screen.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > Feedback_screen.tStartRefresh + 1-frameTolerance:
                # keep track of stop time/frame for later
                Feedback_screen.tStop = t  # not accounting for scr refresh
                Feedback_screen.frameNStop = frameN  # exact frame index
                win.timeOnFlip(Feedback_screen, 'tStopRefresh')  # time at next scr refresh
                Feedback_screen.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in FeedbackComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Feedback"-------
    for thisComponent in FeedbackComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    thisExp.nextEntry()
    
# completed 1 repeats of 'Prac'


# ------Prepare to start Routine "EndPrac"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_5.keys = []
key_resp_5.rt = []
_key_resp_5_allKeys = []
# keep track of which components have finished
EndPracComponents = [text, key_resp_5]
for thisComponent in EndPracComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
EndPracClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "EndPrac"-------
while continueRoutine:
    # get current time
    t = EndPracClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=EndPracClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        text.setAutoDraw(True)
    
    # *key_resp_5* updates
    waitOnFlip = False
    if key_resp_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_5.frameNStart = frameN  # exact frame index
        key_resp_5.tStart = t  # local t and not account for scr refresh
        key_resp_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_5, 'tStartRefresh')  # time at next scr refresh
        key_resp_5.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_5.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_5.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_5.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_5_allKeys.extend(theseKeys)
        if len(_key_resp_5_allKeys):
            key_resp_5.keys = _key_resp_5_allKeys[-1].name  # just the last key pressed
            key_resp_5.rt = _key_resp_5_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in EndPracComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "EndPrac"-------
for thisComponent in EndPracComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('text.started', text.tStartRefresh)
thisExp.addData('text.stopped', text.tStopRefresh)
# check responses
if key_resp_5.keys in ['', [], None]:  # No response was made
    key_resp_5.keys = None
thisExp.addData('key_resp_5.keys',key_resp_5.keys)
if key_resp_5.keys != None:  # we had a response
    thisExp.addData('key_resp_5.rt', key_resp_5.rt)
thisExp.addData('key_resp_5.started', key_resp_5.tStartRefresh)
thisExp.addData('key_resp_5.stopped', key_resp_5.tStopRefresh)
thisExp.nextEntry()
# the Routine "EndPrac" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# ------Prepare to start Routine "startProbe"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
startProbeComponents = [p_port, image]
for thisComponent in startProbeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
startProbeClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "startProbe"-------
while continueRoutine:
    # get current time
    t = startProbeClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=startProbeClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    # *p_port* updates
    if p_port.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        p_port.frameNStart = frameN  # exact frame index
        p_port.tStart = t  # local t and not account for scr refresh
        p_port.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(p_port, 'tStartRefresh')  # time at next scr refresh
        p_port.status = STARTED
        win.callOnFlip(p_port.setData, int(255))
    if p_port.status == STARTED:
        if frameN >= (p_port.frameNStart + 30):
            # keep track of stop time/frame for later
            p_port.tStop = t  # not accounting for scr refresh
            p_port.frameNStop = frameN  # exact frame index
            win.timeOnFlip(p_port, 'tStopRefresh')  # time at next scr refresh
            p_port.status = FINISHED
            win.callOnFlip(p_port.setData, int(0))
    
    # *image* updates
    if image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image.frameNStart = frameN  # exact frame index
        image.tStart = t  # local t and not account for scr refresh
        image.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
        image.setAutoDraw(True)
    if image.status == STARTED:
        if frameN >= (image.frameNStart + 31):
            # keep track of stop time/frame for later
            image.tStop = t  # not accounting for scr refresh
            image.frameNStop = frameN  # exact frame index
            win.timeOnFlip(image, 'tStopRefresh')  # time at next scr refresh
            image.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in startProbeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "startProbe"-------
for thisComponent in startProbeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
if p_port.status == STARTED:
    win.callOnFlip(p_port.setData, int(0))
thisExp.addData('p_port.started', p_port.tStart)
thisExp.addData('p_port.stopped', p_port.tStop)
thisExp.addData('image.started', image.tStartRefresh)
thisExp.addData('image.stopped', image.tStopRefresh)
# the Routine "startProbe" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
Blocks = data.TrialHandler(nReps=3, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='Blocks')
thisExp.addLoop(Blocks)  # add the loop to the experiment
thisBlock = Blocks.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
if thisBlock != None:
    for paramName in thisBlock:
        exec('{} = thisBlock[paramName]'.format(paramName))

for thisBlock in Blocks:
    currentLoop = Blocks
    # abbreviate parameter names if possible (e.g. rgb = thisBlock.rgb)
    if thisBlock != None:
        for paramName in thisBlock:
            exec('{} = thisBlock[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    Trials = data.TrialHandler(nReps=1, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('ANT_TrialSheet.xlsx'),
        seed=None, name='Trials')
    thisExp.addLoop(Trials)  # add the loop to the experiment
    thisTrial = Trials.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    for thisTrial in Trials:
        currentLoop = Trials
        # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
        if thisTrial != None:
            for paramName in thisTrial:
                exec('{} = thisTrial[paramName]'.format(paramName))
        
        # ------Prepare to start Routine "Exp_FixCue"-------
        continueRoutine = True
        # update component parameters for each repeat
        jitter = np.random.choice(np.arange(1.4, 2.6, .1))
        jitter2 = jitter + 1
        Exp_Fixation.setPos((Fixation_LocationX,Fixation_LocationY))
        Exp_Fixation.setImage(Fixation)
        Exp_Cue1.setPos((Cue1_LocationX,Cue1_LocationY))
        Exp_Cue1.setImage(Cue1)
        Exp_Cue2.setPos((Cue2_LocationX,Cue2_LocationY))
        Exp_Cue2.setImage(Cue2)
        # keep track of which components have finished
        Exp_FixCueComponents = [trialStartPort, Exp_Fixation, Exp_Cue1, Exp_Cue2, cuePort]
        for thisComponent in Exp_FixCueComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        Exp_FixCueClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "Exp_FixCue"-------
        while continueRoutine:
            # get current time
            t = Exp_FixCueClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=Exp_FixCueClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # *trialStartPort* updates
            if trialStartPort.status == NOT_STARTED and t >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                trialStartPort.frameNStart = frameN  # exact frame index
                trialStartPort.tStart = t  # local t and not account for scr refresh
                trialStartPort.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(trialStartPort, 'tStartRefresh')  # time at next scr refresh
                trialStartPort.status = STARTED
                win.callOnFlip(trialStartPort.setData, int(255))
            if trialStartPort.status == STARTED:
                if frameN >= (trialStartPort.frameNStart + 4):
                    # keep track of stop time/frame for later
                    trialStartPort.tStop = t  # not accounting for scr refresh
                    trialStartPort.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(trialStartPort, 'tStopRefresh')  # time at next scr refresh
                    trialStartPort.status = FINISHED
                    win.callOnFlip(trialStartPort.setData, int(0))
            
            # *Exp_Fixation* updates
            if Exp_Fixation.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                Exp_Fixation.frameNStart = frameN  # exact frame index
                Exp_Fixation.tStart = t  # local t and not account for scr refresh
                Exp_Fixation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Exp_Fixation, 'tStartRefresh')  # time at next scr refresh
                Exp_Fixation.setAutoDraw(True)
            if Exp_Fixation.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Exp_Fixation.tStartRefresh + jitter2-frameTolerance:
                    # keep track of stop time/frame for later
                    Exp_Fixation.tStop = t  # not accounting for scr refresh
                    Exp_Fixation.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Exp_Fixation, 'tStopRefresh')  # time at next scr refresh
                    Exp_Fixation.setAutoDraw(False)
            
            # *Exp_Cue1* updates
            if Exp_Cue1.status == NOT_STARTED and tThisFlip >= jitter-frameTolerance:
                # keep track of start time/frame for later
                Exp_Cue1.frameNStart = frameN  # exact frame index
                Exp_Cue1.tStart = t  # local t and not account for scr refresh
                Exp_Cue1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Exp_Cue1, 'tStartRefresh')  # time at next scr refresh
                Exp_Cue1.setAutoDraw(True)
            if Exp_Cue1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Exp_Cue1.tStartRefresh + .1-frameTolerance:
                    # keep track of stop time/frame for later
                    Exp_Cue1.tStop = t  # not accounting for scr refresh
                    Exp_Cue1.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Exp_Cue1, 'tStopRefresh')  # time at next scr refresh
                    Exp_Cue1.setAutoDraw(False)
            
            # *Exp_Cue2* updates
            if Exp_Cue2.status == NOT_STARTED and tThisFlip >= jitter-frameTolerance:
                # keep track of start time/frame for later
                Exp_Cue2.frameNStart = frameN  # exact frame index
                Exp_Cue2.tStart = t  # local t and not account for scr refresh
                Exp_Cue2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Exp_Cue2, 'tStartRefresh')  # time at next scr refresh
                Exp_Cue2.setAutoDraw(True)
            if Exp_Cue2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Exp_Cue2.tStartRefresh + .1-frameTolerance:
                    # keep track of stop time/frame for later
                    Exp_Cue2.tStop = t  # not accounting for scr refresh
                    Exp_Cue2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Exp_Cue2, 'tStopRefresh')  # time at next scr refresh
                    Exp_Cue2.setAutoDraw(False)
            # *cuePort* updates
            if cuePort.status == NOT_STARTED and t >= jitter-frameTolerance:
                # keep track of start time/frame for later
                cuePort.frameNStart = frameN  # exact frame index
                cuePort.tStart = t  # local t and not account for scr refresh
                cuePort.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(cuePort, 'tStartRefresh')  # time at next scr refresh
                cuePort.status = STARTED
                win.callOnFlip(cuePort.setData, int(255))
            if cuePort.status == STARTED:
                if frameN >= (cuePort.frameNStart + 6):
                    # keep track of stop time/frame for later
                    cuePort.tStop = t  # not accounting for scr refresh
                    cuePort.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(cuePort, 'tStopRefresh')  # time at next scr refresh
                    cuePort.status = FINISHED
                    win.callOnFlip(cuePort.setData, int(0))
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Exp_FixCueComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "Exp_FixCue"-------
        for thisComponent in Exp_FixCueComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        if trialStartPort.status == STARTED:
            win.callOnFlip(trialStartPort.setData, int(0))
        Trials.addData('trialStartPort.started', trialStartPort.tStart)
        Trials.addData('trialStartPort.stopped', trialStartPort.tStop)
        Trials.addData('Exp_Fixation.started', Exp_Fixation.tStartRefresh)
        Trials.addData('Exp_Fixation.stopped', Exp_Fixation.tStopRefresh)
        Trials.addData('Exp_Cue1.started', Exp_Cue1.tStartRefresh)
        Trials.addData('Exp_Cue1.stopped', Exp_Cue1.tStopRefresh)
        Trials.addData('Exp_Cue2.started', Exp_Cue2.tStartRefresh)
        Trials.addData('Exp_Cue2.stopped', Exp_Cue2.tStopRefresh)
        if cuePort.status == STARTED:
            win.callOnFlip(cuePort.setData, int(0))
        Trials.addData('cuePort.started', cuePort.tStart)
        Trials.addData('cuePort.stopped', cuePort.tStop)
        # the Routine "Exp_FixCue" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "Exp_Trial"-------
        continueRoutine = True
        # update component parameters for each repeat
        Exp_Fixation2.setPos((Fixation_LocationX,Fixation_LocationY))
        Exp_Fixation2.setImage(Fixation)
        Exp_Target.setPos((Target_Arrow_LocationX,Target_Arrow_LocationY))
        Exp_Target.setImage(Target_Arrow)
        Exp_Flanker1.setPos((Flanker1_LocationX,Flanker1_LocationY))
        Exp_Flanker1.setImage(Flanker1)
        Exp_Flanker2.setPos((Flanker2_LocationX,Flanker2_LocationY))
        Exp_Flanker2.setImage(Flanker2)
        Exp_Flanker3.setPos((Flanker3_LocationX,Flanker3_LocationY))
        Exp_Flanker3.setImage(Flanker3)
        Exp_Flanker4.setPos((Flanker4_LocationX,Flanker4_LocationY))
        ExpResp.keys = []
        ExpResp.rt = []
        _ExpResp_allKeys = []
        # keep track of which components have finished
        Exp_TrialComponents = [Exp_Fixation2, Exp_Target, Exp_Flanker1, Exp_Flanker2, Exp_Flanker3, Exp_Flanker4, ExpResp, targetPort]
        for thisComponent in Exp_TrialComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        Exp_TrialClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "Exp_Trial"-------
        while continueRoutine:
            # get current time
            t = Exp_TrialClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=Exp_TrialClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *Exp_Fixation2* updates
            if Exp_Fixation2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                Exp_Fixation2.frameNStart = frameN  # exact frame index
                Exp_Fixation2.tStart = t  # local t and not account for scr refresh
                Exp_Fixation2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Exp_Fixation2, 'tStartRefresh')  # time at next scr refresh
                Exp_Fixation2.setAutoDraw(True)
            
            # *Exp_Target* updates
            if Exp_Target.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
                # keep track of start time/frame for later
                Exp_Target.frameNStart = frameN  # exact frame index
                Exp_Target.tStart = t  # local t and not account for scr refresh
                Exp_Target.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Exp_Target, 'tStartRefresh')  # time at next scr refresh
                Exp_Target.setAutoDraw(True)
            if Exp_Target.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Exp_Target.tStartRefresh + 1.7-frameTolerance:
                    # keep track of stop time/frame for later
                    Exp_Target.tStop = t  # not accounting for scr refresh
                    Exp_Target.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Exp_Target, 'tStopRefresh')  # time at next scr refresh
                    Exp_Target.setAutoDraw(False)
            
            # *Exp_Flanker1* updates
            if Exp_Flanker1.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
                # keep track of start time/frame for later
                Exp_Flanker1.frameNStart = frameN  # exact frame index
                Exp_Flanker1.tStart = t  # local t and not account for scr refresh
                Exp_Flanker1.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Exp_Flanker1, 'tStartRefresh')  # time at next scr refresh
                Exp_Flanker1.setAutoDraw(True)
            if Exp_Flanker1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Exp_Flanker1.tStartRefresh + 1.7-frameTolerance:
                    # keep track of stop time/frame for later
                    Exp_Flanker1.tStop = t  # not accounting for scr refresh
                    Exp_Flanker1.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Exp_Flanker1, 'tStopRefresh')  # time at next scr refresh
                    Exp_Flanker1.setAutoDraw(False)
            
            # *Exp_Flanker2* updates
            if Exp_Flanker2.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
                # keep track of start time/frame for later
                Exp_Flanker2.frameNStart = frameN  # exact frame index
                Exp_Flanker2.tStart = t  # local t and not account for scr refresh
                Exp_Flanker2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Exp_Flanker2, 'tStartRefresh')  # time at next scr refresh
                Exp_Flanker2.setAutoDraw(True)
            if Exp_Flanker2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Exp_Flanker2.tStartRefresh + 1.7-frameTolerance:
                    # keep track of stop time/frame for later
                    Exp_Flanker2.tStop = t  # not accounting for scr refresh
                    Exp_Flanker2.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Exp_Flanker2, 'tStopRefresh')  # time at next scr refresh
                    Exp_Flanker2.setAutoDraw(False)
            
            # *Exp_Flanker3* updates
            if Exp_Flanker3.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
                # keep track of start time/frame for later
                Exp_Flanker3.frameNStart = frameN  # exact frame index
                Exp_Flanker3.tStart = t  # local t and not account for scr refresh
                Exp_Flanker3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Exp_Flanker3, 'tStartRefresh')  # time at next scr refresh
                Exp_Flanker3.setAutoDraw(True)
            if Exp_Flanker3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Exp_Flanker3.tStartRefresh + 1.7-frameTolerance:
                    # keep track of stop time/frame for later
                    Exp_Flanker3.tStop = t  # not accounting for scr refresh
                    Exp_Flanker3.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Exp_Flanker3, 'tStopRefresh')  # time at next scr refresh
                    Exp_Flanker3.setAutoDraw(False)
            
            # *Exp_Flanker4* updates
            if Exp_Flanker4.status == NOT_STARTED and tThisFlip >= .4-frameTolerance:
                # keep track of start time/frame for later
                Exp_Flanker4.frameNStart = frameN  # exact frame index
                Exp_Flanker4.tStart = t  # local t and not account for scr refresh
                Exp_Flanker4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(Exp_Flanker4, 'tStartRefresh')  # time at next scr refresh
                Exp_Flanker4.setAutoDraw(True)
            if Exp_Flanker4.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > Exp_Flanker4.tStartRefresh + 1.7-frameTolerance:
                    # keep track of stop time/frame for later
                    Exp_Flanker4.tStop = t  # not accounting for scr refresh
                    Exp_Flanker4.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(Exp_Flanker4, 'tStopRefresh')  # time at next scr refresh
                    Exp_Flanker4.setAutoDraw(False)
            if Exp_Flanker4.status == STARTED:  # only update if drawing
                Exp_Flanker4.setImage(Flanker4, log=False)
            
            # *ExpResp* updates
            waitOnFlip = False
            if ExpResp.status == NOT_STARTED and tThisFlip >= .416-frameTolerance:
                # keep track of start time/frame for later
                ExpResp.frameNStart = frameN  # exact frame index
                ExpResp.tStart = t  # local t and not account for scr refresh
                ExpResp.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(ExpResp, 'tStartRefresh')  # time at next scr refresh
                ExpResp.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(ExpResp.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(ExpResp.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if ExpResp.status == STARTED and not waitOnFlip:
                theseKeys = ExpResp.getKeys(keyList=['left', 'right'], waitRelease=False)
                _ExpResp_allKeys.extend(theseKeys)
                if len(_ExpResp_allKeys):
                    ExpResp.keys = _ExpResp_allKeys[-1].name  # just the last key pressed
                    ExpResp.rt = _ExpResp_allKeys[-1].rt
                    # was this correct?
                    if (ExpResp.keys == str(Correct)) or (ExpResp.keys == Correct):
                        ExpResp.corr = 1
                    else:
                        ExpResp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            # *targetPort* updates
            if targetPort.status == NOT_STARTED and t >= 0.4-frameTolerance:
                # keep track of start time/frame for later
                targetPort.frameNStart = frameN  # exact frame index
                targetPort.tStart = t  # local t and not account for scr refresh
                targetPort.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(targetPort, 'tStartRefresh')  # time at next scr refresh
                targetPort.status = STARTED
                win.callOnFlip(targetPort.setData, int(255))
            if targetPort.status == STARTED:
                if frameN >= (targetPort.frameNStart + 1):
                    # keep track of stop time/frame for later
                    targetPort.tStop = t  # not accounting for scr refresh
                    targetPort.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(targetPort, 'tStopRefresh')  # time at next scr refresh
                    targetPort.status = FINISHED
                    win.callOnFlip(targetPort.setData, int(0))
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in Exp_TrialComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "Exp_Trial"-------
        for thisComponent in Exp_TrialComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        Trials.addData('Exp_Fixation2.started', Exp_Fixation2.tStartRefresh)
        Trials.addData('Exp_Fixation2.stopped', Exp_Fixation2.tStopRefresh)
        Trials.addData('Exp_Target.started', Exp_Target.tStartRefresh)
        Trials.addData('Exp_Target.stopped', Exp_Target.tStopRefresh)
        Trials.addData('Exp_Flanker1.started', Exp_Flanker1.tStartRefresh)
        Trials.addData('Exp_Flanker1.stopped', Exp_Flanker1.tStopRefresh)
        Trials.addData('Exp_Flanker2.started', Exp_Flanker2.tStartRefresh)
        Trials.addData('Exp_Flanker2.stopped', Exp_Flanker2.tStopRefresh)
        Trials.addData('Exp_Flanker3.started', Exp_Flanker3.tStartRefresh)
        Trials.addData('Exp_Flanker3.stopped', Exp_Flanker3.tStopRefresh)
        Trials.addData('Exp_Flanker4.started', Exp_Flanker4.tStartRefresh)
        Trials.addData('Exp_Flanker4.stopped', Exp_Flanker4.tStopRefresh)
        # check responses
        if ExpResp.keys in ['', [], None]:  # No response was made
            ExpResp.keys = None
            # was no response the correct answer?!
            if str(Correct).lower() == 'none':
               ExpResp.corr = 1;  # correct non-response
            else:
               ExpResp.corr = 0;  # failed to respond (incorrectly)
        # store data for Trials (TrialHandler)
        Trials.addData('ExpResp.keys',ExpResp.keys)
        Trials.addData('ExpResp.corr', ExpResp.corr)
        if ExpResp.keys != None:  # we had a response
            Trials.addData('ExpResp.rt', ExpResp.rt)
        Trials.addData('ExpResp.started', ExpResp.tStartRefresh)
        Trials.addData('ExpResp.stopped', ExpResp.tStopRefresh)
        if targetPort.status == STARTED:
            win.callOnFlip(targetPort.setData, int(0))
        Trials.addData('targetPort.started', targetPort.tStart)
        Trials.addData('targetPort.stopped', targetPort.tStop)
        # the Routine "Exp_Trial" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # ------Prepare to start Routine "ping"-------
        continueRoutine = True
        routineTimer.add(1.000000)
        # update component parameters for each repeat
        fixationEnd.setPos((Fixation_LocationX,Fixation_LocationY))
        fixationEnd.setImage(Fixation)
        # keep track of which components have finished
        pingComponents = [responsePort, fixationEnd]
        for thisComponent in pingComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        pingClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
        frameN = -1
        
        # -------Run Routine "ping"-------
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = pingClock.getTime()
            tThisFlip = win.getFutureFlipTime(clock=pingClock)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # *responsePort* updates
            if responsePort.status == NOT_STARTED and t >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                responsePort.frameNStart = frameN  # exact frame index
                responsePort.tStart = t  # local t and not account for scr refresh
                responsePort.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(responsePort, 'tStartRefresh')  # time at next scr refresh
                responsePort.status = STARTED
                responsePort.setData(int(255))
            if responsePort.status == STARTED:
                if frameN >= (responsePort.frameNStart + 8):
                    # keep track of stop time/frame for later
                    responsePort.tStop = t  # not accounting for scr refresh
                    responsePort.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(responsePort, 'tStopRefresh')  # time at next scr refresh
                    responsePort.status = FINISHED
                    responsePort.setData(int(0))
            
            # *fixationEnd* updates
            if fixationEnd.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fixationEnd.frameNStart = frameN  # exact frame index
                fixationEnd.tStart = t  # local t and not account for scr refresh
                fixationEnd.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixationEnd, 'tStartRefresh')  # time at next scr refresh
                fixationEnd.setAutoDraw(True)
            if fixationEnd.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixationEnd.tStartRefresh + 1-frameTolerance:
                    # keep track of stop time/frame for later
                    fixationEnd.tStop = t  # not accounting for scr refresh
                    fixationEnd.frameNStop = frameN  # exact frame index
                    win.timeOnFlip(fixationEnd, 'tStopRefresh')  # time at next scr refresh
                    fixationEnd.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in pingComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # -------Ending Routine "ping"-------
        for thisComponent in pingComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        if responsePort.status == STARTED:
            responsePort.setData(int(0))
        Trials.addData('responsePort.started', responsePort.tStart)
        Trials.addData('responsePort.stopped', responsePort.tStop)
        Trials.addData('fixationEnd.started', fixationEnd.tStartRefresh)
        Trials.addData('fixationEnd.stopped', fixationEnd.tStopRefresh)
        thisExp.nextEntry()
        
    # completed 1 repeats of 'Trials'
    
    
    # ------Prepare to start Routine "Break"-------
    continueRoutine = True
    # update component parameters for each repeat
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    # keep track of which components have finished
    BreakComponents = [Break_Slide, key_resp]
    for thisComponent in BreakComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    BreakClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "Break"-------
    while continueRoutine:
        # get current time
        t = BreakClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=BreakClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *Break_Slide* updates
        if Break_Slide.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            Break_Slide.frameNStart = frameN  # exact frame index
            Break_Slide.tStart = t  # local t and not account for scr refresh
            Break_Slide.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Break_Slide, 'tStartRefresh')  # time at next scr refresh
            Break_Slide.setAutoDraw(True)
        
        # *key_resp* updates
        waitOnFlip = False
        if key_resp.status == NOT_STARTED and tThisFlip >= 5-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=['space'], waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
                key_resp.rt = _key_resp_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in BreakComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "Break"-------
    for thisComponent in BreakComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    Blocks.addData('Break_Slide.started', Break_Slide.tStartRefresh)
    Blocks.addData('Break_Slide.stopped', Break_Slide.tStopRefresh)
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    Blocks.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        Blocks.addData('key_resp.rt', key_resp.rt)
    Blocks.addData('key_resp.started', key_resp.tStartRefresh)
    Blocks.addData('key_resp.stopped', key_resp.tStopRefresh)
    # the Routine "Break" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
# completed 3 repeats of 'Blocks'


# ------Prepare to start Routine "EndStudy"-------
continueRoutine = True
# update component parameters for each repeat
key_resp_6.keys = []
key_resp_6.rt = []
_key_resp_6_allKeys = []
# keep track of which components have finished
EndStudyComponents = [EndofStudy, key_resp_6]
for thisComponent in EndStudyComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
EndStudyClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "EndStudy"-------
while continueRoutine:
    # get current time
    t = EndStudyClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=EndStudyClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *EndofStudy* updates
    if EndofStudy.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        EndofStudy.frameNStart = frameN  # exact frame index
        EndofStudy.tStart = t  # local t and not account for scr refresh
        EndofStudy.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(EndofStudy, 'tStartRefresh')  # time at next scr refresh
        EndofStudy.setAutoDraw(True)
    
    # *key_resp_6* updates
    waitOnFlip = False
    if key_resp_6.status == NOT_STARTED and tThisFlip >= 1-frameTolerance:
        # keep track of start time/frame for later
        key_resp_6.frameNStart = frameN  # exact frame index
        key_resp_6.tStart = t  # local t and not account for scr refresh
        key_resp_6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_6, 'tStartRefresh')  # time at next scr refresh
        key_resp_6.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_6.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_6.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_6.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_6.getKeys(keyList=['y', 'n', 'left', 'right', 'space'], waitRelease=False)
        _key_resp_6_allKeys.extend(theseKeys)
        if len(_key_resp_6_allKeys):
            key_resp_6.keys = _key_resp_6_allKeys[-1].name  # just the last key pressed
            key_resp_6.rt = _key_resp_6_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in EndStudyComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "EndStudy"-------
for thisComponent in EndStudyComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
thisExp.addData('EndofStudy.started', EndofStudy.tStartRefresh)
thisExp.addData('EndofStudy.stopped', EndofStudy.tStopRefresh)
# check responses
if key_resp_6.keys in ['', [], None]:  # No response was made
    key_resp_6.keys = None
thisExp.addData('key_resp_6.keys',key_resp_6.keys)
if key_resp_6.keys != None:  # we had a response
    thisExp.addData('key_resp_6.rt', key_resp_6.rt)
thisExp.addData('key_resp_6.started', key_resp_6.tStartRefresh)
thisExp.addData('key_resp_6.stopped', key_resp_6.tStopRefresh)
thisExp.nextEntry()
# the Routine "EndStudy" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
